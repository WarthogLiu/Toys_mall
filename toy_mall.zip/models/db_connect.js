// 数据库连接地址

const db_connect = 'mongodb+srv://guest:iJewL2J8ACoo3Xe5@mymongodb-rdfvx.azure.mongodb.net/test?retryWrites=true&w=majority'

module.exports = db_connect